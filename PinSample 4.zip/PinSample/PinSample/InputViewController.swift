//
//  InputViewController.swift
//  PinSample
//
//  Created by Han  on 2020/8/14.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import MapKit
class InputViewController: UIViewController {
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var FIND: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func findPlace(_ sender: Any) {
        getCoordinate(addressString: input.text!, completionHandler: display)
    }
    
    func getCoordinate(addressString : String,
            completionHandler: @escaping(CLLocationCoordinate2D, NSError?) -> Void ) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(addressString) { (placemarks, error) in
            if error == nil {
                if let placemark = placemarks?[0] {
                    let location = placemark.location!
                        
                    completionHandler(location.coordinate, nil)
                    return
                }
            }
                
            completionHandler(kCLLocationCoordinate2DInvalid, error as NSError?)
        }
    }
    func display(loc: CLLocationCoordinate2D, error: NSError?) {
        //print("reach")
        performSegue(withIdentifier: "nextlink", sender: loc)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "nextlink" {
            let nextpage = segue.destination as! LinkViewController
            nextpage.coordinate = sender as! CLLocationCoordinate2D
        }
    }
    
    
    
}
