//
//  logininfo.swift
//  PinSample
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
struct logininfo: Codable {
    let username: String
    let password: String
}
