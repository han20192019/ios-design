//
//  MapAPI.swift
//  PinSample
//
//  Created by Han  on 2020/8/14.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class MapAPI {
    enum Endpoints {
        case getLocation
        case newLocation
        case login
        
        var url: URL {
            return URL(string: self.stringValue)!
        }
        
        var stringValue: String {
            switch self {
            case .getLocation:
                return "https://onthemap-api.udacity.com/v1/StudentLocation?limit=100&order=-updatedAt"
            case .newLocation:
                return "https://onthemap-api.udacity.com/v1/StudentLocation"
            case .login:
                return "https://onthemap-api.udacity.com/v1/session"
            }
        }
    }
    class func taskForGETRequest<ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) -> URLSessionDataTask {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                /*
                do {
                    let errorResponse = try decoder.decode(LocationResult.self, from: data) as Error
                    DispatchQueue.main.async {
                        completion(nil, errorResponse)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
                */
            }
        }
        task.resume()
        
        return task
    }
    
    class func taskForPOSTRequest<RequestType: Encodable, ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, body: RequestType, completion: @escaping (ResponseType?, Error?) -> Void) {
        print("reach1")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try! JSONEncoder().encode(body)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            print(responseType)
            if (responseType == LoginResponse.self) {
                print("yes")
                request.addValue("application/json", forHTTPHeaderField: "Accept")
            }
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                print(responseObject)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                /*
                do {
                    let errorResponse = try decoder.decode(TMDBResponse.self, from: data) as Error
                    DispatchQueue.main.async {
                        completion(nil, errorResponse)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
                */
            }
        }
        task.resume()
    }
    
    
    
    class func getStudentLocation(completion: @escaping ([StudentLocation], Error?) -> Void) {
        taskForGETRequest(url: Endpoints.getLocation.url, responseType: LocationResult.self) { response, error in
            if let response = response {
                completion(response.results!, nil)
            } else {
                completion([], error)
            }
        }
    }
    
    class func makeNewLocation(uniqueKey: String, firstName:String, lastName: String, mapString: String, mediaURL: String, latitude: Double, longitude: Double, completion: @escaping (Bool, Error?) -> Void) {
        let body = CreateNewLocation(firstName: firstName, lastName: lastName, latitude: latitude, longitude: longitude, mapString: mapString, mediaURL: mediaURL, uniqueKey: uniqueKey)
        taskForPOSTRequest(url: Endpoints.newLocation.url, responseType: CreateResponse.self, body: body) { response, error in
            if let response = response {
                // separate codes are used for posting, deleting, and updating a response
                // all are considered "successful"
                /*
                completion(response.statusCode == 1 || response.statusCode == 12 || response.statusCode == 13, nil)
                */
                print("reachnewadding")
                print(response.createdAt)
                completion(true, nil)
            } else {
                completion(false, nil)
            }
        }
    }
    
    class func login(username: String, password: String, completion: @escaping (Bool, Error?) -> Void) {
        let body = LoginRequest(udacity: logininfo(username: username, password: password))
        taskForPOSTRequest(url: Endpoints.login.url, responseType: LoginResponse.self, body: body) { response, error in
            if let response = response {
                if (response.account!.registered)
                {
                    print(response.session!.id)
                    completion(true, nil)
                }
                else {
                    completion(false, error)
                }
            } else {
                completion(false, error)
            }
        }
    }
    


}
