//
//  LoginViewController.swift
//  PinSample
//
//  Created by Han  on 2020/8/17.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var submitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func submit(_ sender: Any) {
        MapAPI.login(username: username.text!, password: password.text!, completion: doNext)
    }
    func doNext(response: Bool, err: Error?) {
        print(response)
        if response {
            performSegue(withIdentifier: "login", sender: nil)
        } else {
            print(err)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
