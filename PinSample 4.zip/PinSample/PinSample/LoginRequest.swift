//
//  LoginRequest.swift
//  PinSample
//
//  Created by Han  on 2020/8/17.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
struct LoginRequest: Codable {
    let udacity: logininfo
}
