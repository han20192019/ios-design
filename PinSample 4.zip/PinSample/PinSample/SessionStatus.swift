//
//  SessionStatus.swift
//  PinSample
//
//  Created by Han  on 2020/8/17.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
struct SessionStatus: Codable {
    let id: String
    let expiration: String
}
