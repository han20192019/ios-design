//
//  HistoryViewController.swift
//  RockPaperScissors
//
//  Created by Han  on 2020/8/3.
//  Copyright © 2020 Gabrielle Miller-Messner. All rights reserved.
//
import Foundation
import UIKit

class HistoryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var HistoryTable: UITableView!
    
    var historyrecord = [RPSMatch]()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return historyrecord.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("reach")
        let cell =  tableView.dequeueReusableCell(withIdentifier: "record")!
        
        let dict = self.historyrecord[(indexPath as NSIndexPath).row]
    
        cell.textLabel?.text = victoryStatusDescription(dict)
        //cell.textLabel?.text = dictionary["text"]
        cell.detailTextLabel?.text = "\(dict.p1) vs. \(dict.p2)"
        
        return cell
    }
    
    func victoryStatusDescription(_ match: RPSMatch) -> String {
        
        if (match.p1 == match.p2) {
            return "Tie."
        } else if (match.p1.defeats(match.p2)) {
            return "Win!"
        } else {
            return "Loss."
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
