//
//  ViewController.swift
//  TripHelper
//
//  Created by Han  on 2020/8/20.
//  Copyright © 2020 Han . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print(2)
        poiAPI.getpoi() {_,_ in print(1)
        }
    }


}

