//
//  poiResponse.swift
//  TripHelper
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation
struct poiResponse: Codable {
    
    let type: String
    let subType: String
    let id: String
    let self_info: self_info
    let geoCode: geoCode
    let name: String
    let category: String
    let rank: Int
    let tags: [String]

    
    enum CodingKeys: String, CodingKey {
        case type
        case subType
        case id
        case self_info = "self"
        case geoCode
        case name
        case category
        case rank
        case tags
        
    }
}
