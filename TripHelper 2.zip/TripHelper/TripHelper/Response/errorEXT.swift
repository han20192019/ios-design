//
//  errorEXT.swift
//  TripHelper
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation
struct errorEXT: Codable {
    let parameter: String
    let example: String
}
