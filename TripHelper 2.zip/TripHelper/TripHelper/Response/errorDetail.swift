//
//  errorDetail.swift
//  TripHelper
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation
struct errorDetail: Codable {
    let status: Int
    let code: Int
    let title: String
    let detail: String
    let source: errorEXT
}
