//
//  metainclude.swift
//  TripHelper
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation
struct metainclude: Codable {
    
    let self_info: String
    let next: String
    let last: String
    let first: String
    let up: String
    
    enum CodingKeys: String, CodingKey {
        case self_info = "self"
        case next
        case last
        case first
        case up
        
    }
}
