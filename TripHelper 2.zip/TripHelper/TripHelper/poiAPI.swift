//
//  poiAPI.swift
//  TripHelper
//
//  Created by Han  on 2020/8/21.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation

class poiAPI {
    
    enum Endpoints {
        
        case getpoi
        
        var stringValue: String {
            switch self {
            case .getpoi: return "https://test.api.amadeus.com/v1/reference-data/locations/pois?latitude=41.397158&longitude=2.160873&radius=1&page%5Blimit%5D=10&page%5Boffset%5D=0"
            /*
            case .getpoi: return Endpoints.base + "/account/\(Auth.accountId)/watchlist/movies" + Endpoints.apiKeyParam + "&session_id=\(Auth.sessionId)"
                 */
            }

        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func taskForGETRequest<ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) -> URLSessionDataTask {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                print("do1")
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                print("do2")
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                print("err")
                do {
                    let errorResponse = try decoder.decode(ErrorResponse.self, from: data)
                    print(errorResponse.errors)
                } catch {
//                    DispatchQueue.main.async {
//                        completion(nil, error)
//                    }
                    print(data)
                    print("real error")
                }

            }
        }
        task.resume()
        
        return task
    }
    
    class func taskForPOSTRequest<RequestType: Encodable, ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, body: RequestType, completion: @escaping (ResponseType?, Error?) -> Void) {
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try! JSONEncoder().encode(body)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
//                do {
//                    let errorResponse = try decoder.decode(TMDBResponse.self, from: data) as Error
//                    DispatchQueue.main.async {
//                        completion(nil, errorResponse)
//                    }
//                } catch {
//                    DispatchQueue.main.async {
//                        completion(nil, error)
//                    }
//                }
            }
        }
        task.resume()
    }
    
    class func getpoi(completion: @escaping ([poiResponse], Error?) -> Void) {
        print("reach1")
        taskForGETRequest(url: Endpoints.getpoi.url, responseType: poiData.self) { response, error in
            if let response = response {
                let data = response.data
                print("reach2")
                print(data)
            } else {
                print("reach3")
                completion([], error)
            }
        }
    }
    
    
}
