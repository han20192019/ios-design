//
//  PictureDetailViewController.swift
//  MemeMe Version1
//
//  Created by Han  on 2020/8/29.
//  Copyright © 2020 Han . All rights reserved.
//

import UIKit

class PictureDetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("reach")
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
