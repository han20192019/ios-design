//
//  MemeCollectionViewCell.swift
//  MemeMe Version1
//
//  Created by Han  on 2020/8/8.
//  Copyright © 2020 Han . All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    
    
}
