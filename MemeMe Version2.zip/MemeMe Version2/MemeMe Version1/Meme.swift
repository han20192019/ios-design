//
//  Meme.swift
//  MemeMe Version1
//
//  Created by Han  on 2020/8/7.
//  Copyright © 2020 Han . All rights reserved.
//

import Foundation
import UIKit
struct Meme {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}
