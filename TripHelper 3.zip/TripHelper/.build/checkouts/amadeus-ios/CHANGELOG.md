# Changelog

## [1.1.0](https://github.com/amadeus4dev/amadeus-ios/tree/1.1.0) (2020-07-30)

- Add Travel Recommendations API
- Add Safe Place API
- Implement usage of Swift 5.0's Result type

## [1.0.0](https://github.com/amadeus4dev/amadeus-ios/tree/1.0.0) (2020-04-30)

- Initial Release 1.0.0
