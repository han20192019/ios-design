import XCTest

import TripHelperTests

var tests = [XCTestCaseEntry]()
tests += TripHelperTests.allTests()
XCTMain(tests)
