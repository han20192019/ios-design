//
//  CreateNewLocation.swift
//  PinSample
//
//  Created by Han  on 2020/8/14.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
struct CreateNewLocation: Codable {
    let firstName: String
    let lastName: String
    let latitude: Double
    let longitude: Double
    let mapString: String
    let mediaURL: String
    let uniqueKey: String
}
