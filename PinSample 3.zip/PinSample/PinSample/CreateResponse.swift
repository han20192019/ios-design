//
//  CreateResponse.swift
//  PinSample
//
//  Created by Han  on 2020/8/14.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
struct  CreateResponse: Codable {
    let createdAt: String
    let objectId: String
}
