//
//  LinkViewController.swift
//  PinSample
//
//  Created by Han  on 2020/8/14.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import MapKit
class LinkViewController: UIViewController {
    @IBOutlet weak var link: UITextField!
    @IBOutlet weak var MapView: MKMapView!
    
    @IBOutlet weak var submit: UIButton!
    
    var coordinate: CLLocationCoordinate2D?
    override func viewDidLoad() {
        super.viewDidLoad()
        show()
        // Do any additional setup after loading the view.
    }
    
    func show() {
        print(coordinate)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate!
        // When the array is complete, we add the annotations to the map.
        self.MapView.addAnnotations([annotation])
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }


    @IBAction func submitNew(_ sender: Any) {
        MapAPI.makeNewLocation(uniqueKey: "123", firstName: "HF", lastName: "XQ", mapString: "j", mediaURL: link.text!, latitude: coordinate!.latitude, longitude: coordinate!.longitude, completion: refresh)
        performSegue(withIdentifier: "goback", sender: nil)
        
    }
    func refresh(success: Bool, error: Error?) {
        if success {
           //performSegue(withIdentifier: "goback", sender: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
