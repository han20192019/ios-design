//
//  ViewController.swift
//  TouristPre
//
//  Created by Han  on 2020/8/24.
//  Copyright © 2020 Han . All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    var dataController:DataController!
    var fetchedResultsController: NSFetchedResultsController<Picture>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let dataController = DataController(modelName: "TouristPre")
        dataController.load()
        setupFetchedResultsController()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        addPic()
        // Do any additional setup after loading the view.
        for i in fetchedResultsController.fetchedObjects! {
            print(i.name)
        }
    }
    
    fileprivate func setupFetchedResultsController() {
        let fetchRequest:NSFetchRequest<Picture> = Picture.fetchRequest()
        //let predicate = NSPredicate(format: "notebook == %@", notebook)
        //fetchRequest.predicate = predicate
        //let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: true)
        //fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController.delegate = self 

        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    func addPic() {
        let pic = Picture(context: dataController.viewContext)
        pic.name = "haha"
        try? dataController.viewContext.save()
    }
    
    /*
    func getPic() {
        let request = URLRequest(url: URL(string: "http://api.flickr.com/services/feeds/photos_public.gne?tags=vegetables&;tagmode=any&format=json&jsoncallback")!)
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
              if error != nil { // Handle error...
                    print(error)
                  return
              }
            print(String(data: data!, encoding: .utf8)!)
            /*
            let decoder = JSONDecoder()
            do {
                  let responseObject = try decoder.decode(userInfo.self, from: newData!)
                  DispatchQueue.main.async {
                    print(responseObject.first_name)
                    StudentInfo.first = responseObject.first_name
                    StudentInfo.last = responseObject.last_name
                              
                  }
              } catch {
                  print("error")
            }
 */
        }
        task.resume()
    }
     */



}

extension ViewController:NSFetchedResultsControllerDelegate {
    
    
}
