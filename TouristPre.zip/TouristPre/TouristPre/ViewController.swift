//
//  ViewController.swift
//  TouristPre
//
//  Created by Han  on 2020/8/24.
//  Copyright © 2020 Han . All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    var dataController:DataController!
    var pictures: [Picture] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        let fetchRequest:NSFetchRequest<Picture> = Picture.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        if let result = try? dataController.viewContext.fetch(fetchRequest) {
            pictures = result
            for i in pictures {
                print(i.name)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    

    func addPic() {
        let pic = Picture(context: dataController.viewContext)
        pic.name = "haha"
        try? dataController.viewContext.save()
        pictures.append(pic)
        for i in pictures {
            print(i.name)
        }
        
    }
    
    @IBAction func tap(_ sender: Any) {
        addPic()
    }
    /*
    func getPic() {
        let request = URLRequest(url: URL(string: "http://api.flickr.com/services/feeds/photos_public.gne?tags=vegetables&;tagmode=any&format=json&jsoncallback")!)
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
              if error != nil { // Handle error...
                    print(error)
                  return
              }
            print(String(data: data!, encoding: .utf8)!)
            /*
            let decoder = JSONDecoder()
            do {
                  let responseObject = try decoder.decode(userInfo.self, from: newData!)
                  DispatchQueue.main.async {
                    print(responseObject.first_name)
                    StudentInfo.first = responseObject.first_name
                    StudentInfo.last = responseObject.last_name
                              
                  }
              } catch {
                  print("error")
            }
 */
        }
        task.resume()
    }
     */



}

extension ViewController:NSFetchedResultsControllerDelegate {
    
    
}
